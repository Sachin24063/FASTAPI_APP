const express = require('express');
const bodyParser = require('body-parser');
const bookingsRouter = require('./routes/bookings');
const invoicesRouter = require('./routes/invoices');
const cron = require('node-cron');
const { generateInvoices } = require('./services/gstService');

const app = express();

// Middleware
app.use(bodyParser.json());
app.use(express.static('public'));

// Routes
app.use('/bookings', bookingsRouter);
app.use('/invoices', invoicesRouter);

// Schedule task to run every minute to monitor bookings
cron.schedule('* * * * *', generateInvoices);

app.listen(3000, () => {
    console.log('Server running on port 3000');
});
