const Booking = require('../models/bookingModel');
const path = require('path');
const fs = require('fs');

exports.getInvoices = async (req, res) => {
    try {
        const bookings = await Booking.findAll({ where: { status: 'finished' } });

        // Prepare response with invoice details and PDF paths
        const invoiceDetails = bookings.map(booking => {
            const invoicePath = path.join(__dirname, `../public/invoices/invoice-${booking.id}.pdf`);
            return {
                id: booking.id,
                name: booking.name,
                email: booking.email,
                bookingAmount: booking.bookingAmount,
                invoicePath: fs.existsSync(invoicePath) ? `/invoices/invoice-${booking.id}.pdf` : null
            };
        });

        res.json(invoiceDetails);
    } catch (error) {
        console.error('Error fetching invoices:', error);
        res.status(500).json({ message: 'Internal Server Error' });
    }
};
