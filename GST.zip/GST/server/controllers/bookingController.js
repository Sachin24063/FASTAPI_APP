const Booking = require('../models/bookingModel');

// Create a new booking
exports.createBooking = async (req, res) => {
    try {
        const { name, email, bookingAmount, status } = req.body;
        const newBooking = await Booking.create({ name, email, bookingAmount, status });
        res.status(201).json(newBooking);
    } catch (error) {
        console.error('Error creating booking:', error);
        res.status(500).json({ message: 'Internal Server Error' });
    }
};

// Get all bookings
exports.getAllBookings = async (req, res) => {
    try {
        const bookings = await Booking.findAll();
        res.json(bookings);
    } catch (error) {
        console.error('Error fetching bookings:', error);
        res.status(500).json({ message: 'Internal Server Error' });
    }
};
