const { Booking } = require('../models');
const { createInvoice } = require('../utils/invoiceUtils'); // Assuming you have a utility function to create invoices

// Function to generate invoices based on bookings
exports.generateInvoices = async () => {
  try {
    const bookings = await Booking.findAll({
      where: {
        status: 'finished'
      }
    });

    // Check if bookings exist
    if (!bookings || bookings.length === 0) {
      console.log('No finished bookings found.');
      return;
    }

    bookings.forEach(booking => {
      let bookingAmount = booking.bookingAmount;

      // Convert bookingAmount to a number if it's not already
      bookingAmount = parseFloat(bookingAmount);
      
      // Check if the bookingAmount is a valid number
      if (isNaN(bookingAmount)) {
        console.error(`Invalid bookingAmount for booking ID: ${booking.id}`);
        return;
      }

      // Generate the invoice for the booking
      createInvoice(booking, bookingAmount);
      
      // Log the booking details for debugging
      console.log(`Booking ID: ${booking.id}, Amount: ₹${bookingAmount.toFixed(2)}`);
    });
  } catch (error) {
    console.error('Error fetching bookings:', error);
  }
};

// Function to create the invoice (you can expand this function based on your requirements)
const createInvoice = (booking, bookingAmount) => {
  try {
    const invoice = {
      bookingId: booking.id,
      customerName: booking.name,
      customerEmail: booking.email,
      amount: bookingAmount.toFixed(2),
      date: new Date(),
      // Add other invoice fields as needed
    };

    // Assuming you save the invoice in a database or generate a PDF here
    console.log('Invoice generated:', invoice);
  } catch (error) {
    console.error('Error creating invoice:', error);
  }
};
