const { Sequelize } = require('sequelize');

// Create a connection to the database
const sequelize = new Sequelize('mysql://root:tiger@localhost:3306/gst_invoicing');

module.exports = sequelize;
