const express = require('express');
const { getInvoices } = require('../controllers/invoiceController');
const router = express.Router();

router.get('/', getInvoices);

module.exports = router;
